import numpy as np
import matplotlib.pyplot as plt
import mode
import mode_ball
with open('claw_machine.txt', 'r') as file:
    data = []
    for line in file:
        line_data = line.strip().split()  # 去掉换行符并按空格分割
        data.append([float(i) for i in line_data])  # 转换为浮动类型

# 创建一个三维图形
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 设置图形属性
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

ax.set_xlim([-20, 20])  # 设置 x 轴的范围
ax.set_ylim([-20, 20])  # 设置 y 轴的范围
ax.set_zlim([-15, 30])  # 设置 z 轴的范围
# 开始绘制循环
while True:
    # 清空当前坐标轴

    for para in data:
        ax.clear()
        coords = np.array(para).reshape(-1, 3)

        ball = coords[23:]
        point_o = coords[0]
        # 定义三条路径
        line_1 = coords[1:19:3]

        line_2 = coords[2:19:3]

        line_3 = coords[3:19:3]
        target = coords[22]

        line_sum = [line_1, line_2, line_3]

        for line in line_sum:
            x = line[:,0]
            y = line[:,1]
            z = line[:,2]
            ax.scatter(x,y,z, color='r', s=3)  # 绘制点
            ax.plot(x,y,z, color='black', linewidth = 1)  # 绘制线


        # 绘制两点连接线
        for i in range(-1, 2):
            ax.plot([line_sum[i][-1][0], line_sum[i + 1][-1][0]],
                    [line_sum[i][-1][1], line_sum[i + 1][-1][1]],
                    [line_sum[i][-1][2], line_sum[i + 1][-1][2]], color='#FF5733', linewidth=1)

        for i in range(-1, 2):
            ax.plot([line_sum[i][0][0], line_sum[i + 1][0][0]],
                    [line_sum[i][0][1], line_sum[i + 1][0][1]],
                    [line_sum[i][0][2], line_sum[i + 1][0][2]], color='orange', linewidth=1)


        mode.plot_triangle_and_circle_3d(ax,[line_1[2][0], line_1[2][1],line_1[2][2]],
                [line_2[2][0], line_2[2][1],line_2[2][2]],
                [line_3[2][0], line_3[2][1],line_3[2][2]])

        # 追踪球
        mode_ball.plot_sphere(ax,[target[0], target[1], target[2]],4 / (3 ** 0.5))
        mode_ball.plot_xy_plane_1(ax,0,0,line_1[2][2])

        for i in ball:
            mode_ball.plot_sphere(ax, i, 4 / (3 ** 0.5))
        mode_ball.plot_xy_plane(ax,ball[0][0],ball[0][1],ball[0][2])

        # 绘制原点
        ax.scatter(point_o[0], point_o[1], point_o[2], color='r', s=5)
        ax.set_xlim([-30, 30])  # 设置 x 轴的范围
        ax.set_ylim([-30, 30])  # 设置 y 轴的范围
        ax.set_zlim([-15, 40])  # 设置 z 轴的范围
        # 更新图形
        plt.draw()
        ax.invert_zaxis()  # 反转Z轴方向
        plt.pause(0.1)  # 暂停0.1秒，允许更新
