import numpy as np
import matplotlib.pyplot as plt
import mode

with open('spiderhand.txt', 'r') as file:
    data = []
    for line in file:
        line_data = line.strip().split()  # 去掉换行符并按空格分割
        data.append([float(i) for i in line_data])  # 转换为浮动类型

# 创建一个三维图形
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 设置图形属性
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

angle_sum = 0
# 开始绘制循环
while True:
    # 清空当前坐标轴

    for para in data:
        ax.clear()
        coords = np.array(para).reshape(-1, 3)

        point_o = coords[0]
        # 定义三条路径
        line_1 = coords[1:19:3]

        line_2 = coords[2:19:3]

        line_3 = coords[3:19:3]

        line_sum = [line_1, line_2, line_3]


        for line in line_sum:
            for i in range(len(line)):
                ax.scatter(line[i][0], line[i][1], line[i][2], color='r', s=3)  # 绘制点
            for i in range(2):
                ax.plot([line[i][0], line[i + 1][0]], [line[i][1], line[i + 1][1]], [line[i][2], line[i + 1][2]],
                        color='#00FFFF', linewidth=1)  # 绘制线


            for i in range(2,len(line) - 1):
                ax.plot([line[i][0], line[i + 1][0]], [line[i][1], line[i + 1][1]], [line[i][2], line[i + 1][2]],
                        color='black', linewidth=1)  # 绘制线

        # 绘制两点连接线
        for i in range(-1, 2):
            ax.plot([line_sum[i][-1][0], line_sum[i + 1][-1][0]],
                    [line_sum[i][-1][1], line_sum[i + 1][-1][1]],
                    [line_sum[i][-1][2], line_sum[i + 1][-1][2]], color='b', linewidth=1)

        for i in range(-1, 2):
            ax.plot([line_sum[i][0][0], line_sum[i + 1][0][0]],
                    [line_sum[i][0][1], line_sum[i + 1][0][1]],
                    [line_sum[i][0][2], line_sum[i + 1][0][2]], color='orange', linewidth=1)


        mode.plot_triangle_and_circle_3d(ax,[line_sum[0][2][0], line_sum[0][2][1],line_sum[0][2][2]],
                [line_sum[1][2][0], line_sum[1][2][1],line_sum[1][2][2]],
                [line_sum[2][2][0], line_sum[2][2][1],line_sum[2][2][2]])


        for i in range(-1,2):
            angle_new = mode.calculate_angle(line_sum[i][2] - line_sum[i][1], line_sum[i][3] - line_sum[i][2])
            if angle_sum:
                # 精度
                if abs(abs(angle_sum) - abs(angle_new)) > 0.0001:
                    angle_sum = angle_new
                    print(angle_sum)
            else:
                angle_sum = angle_new
                print(angle_new)

        # 绘制原点

        ax.scatter(point_o[0], point_o[1], point_o[2], color='r', s=5)

        ax.set_xlim([-20, 20])  # 设置 x 轴的范围
        ax.set_ylim([-20, 20])  # 设置 y 轴的范围
        ax.set_zlim([-5, 35])  # 设置 z 轴的范围
        # 更新图形
        plt.draw()
        ax.invert_zaxis()  # 反转Z轴方向
        plt.pause(0.01)  # 暂停0.1秒，允许更新
