import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def plot_sphere(ax, center, radius):
    """
    在3D坐标系中绘制一个以给定中心和半径的球
    :param ax: 3D坐标轴
    :param center: 球心 (x0, y0, z0)
    :param radius: 球的半径
    """
    u = np.linspace(0, 2 * np.pi, 100)  # 方位角
    v = np.linspace(0, np.pi, 100)  # 极角

    # 使用球坐标公式生成球面上的点
    x = center[0] + radius * np.outer(np.cos(u), np.sin(v))
    y = center[1] + radius * np.outer(np.sin(u), np.sin(v))
    z = center[2] + radius * np.outer(np.ones(np.size(u)), np.cos(v))

    # 绘制球面
    ax.plot_surface(x, y, z, color='b', alpha=0.3)  # 绘制透明的球面
    ax.scatter(center[0], center[1], center[2], color='r', s=3)  # 绘制点

def plot_xy_plane(ax,x0, y0, z0):# 解包输入点的坐标

    # 创建网格数据
    x = np.linspace(-30,  + 30, 100)
    y = np.linspace(-30,  + 30, 100)
    X, Y = np.meshgrid(x, y)

    # Z值为z0，表示平面高度
    Z = np.full(X.shape, z0)

    # 绘制XY平面
    ax.plot_surface(X, Y, Z, alpha=0.3, color='yellow')

def plot_xy_plane_1(ax,x0, y0, z0):# 解包输入点的坐标

    # 创建网格数据
    x = np.linspace(-30,  + 30, 100)
    y = np.linspace(-30,  + 30, 100)
    X, Y = np.meshgrid(x, y)

    # Z值为z0，表示平面高度
    Z = np.full(X.shape, z0)

    # 绘制XY平面
    ax.plot_surface(X, Y, Z, alpha=0.3, color='green')



