import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import math
def calculate_angle(v1, v2):
    """
    计算两个三维向量 v1 和 v2 的夹角（以度为单位）
    :param v1: 第一个三维向量 (x1, y1, z1)
    :param v2: 第二个三维向量 (x2, y2, z2)
    :return: 夹角（单位：度）
    """
    # 计算点积
    dot_product = np.dot(v1, v2)

    # 计算模长
    magnitude_v1 = np.linalg.norm(v1)
    magnitude_v2 = np.linalg.norm(v2)

    # 计算夹角的余弦值
    cos_theta = dot_product / (magnitude_v1 * magnitude_v2)

    # 防止数值误差导致的溢出，限制范围
    cos_theta = np.clip(cos_theta, -1.0, 1.0)

    # 计算夹角（弧度）
    theta_rad = np.arccos(cos_theta)

    # 转换为度
    theta_deg = np.degrees(theta_rad)

    return theta_deg

def calculate_circle_3d(p1, p2, p3):
    """
    计算三维空间中通过三点的圆心、半径和法向量
    :param p1, p2, p3: 三个点的坐标 (x, y, z)
    :return: 圆心 center, 半径 radius, 法向量 normal
    """
    # 转换为numpy数组
    p1, p2, p3 = np.array(p1), np.array(p2), np.array(p3)

    # 向量定义
    v1 = p2 - p1
    v2 = p3 - p1

    # 法向量（平面法向量）通过叉积计算
    normal = np.cross(v1, v2)
    normal = normal / np.linalg.norm(normal)  # 单位化

    # 三角形边的中点
    mid1 = (p1 + p2) / 2
    mid2 = (p1 + p3) / 2

    # 两边中垂线的方向
    dir1 = np.cross(normal, v1)
    dir2 = np.cross(normal, v2)

    # 解方程找到中垂线的交点，即圆心
    A = np.array([dir1, -dir2, normal]).T  # 系数矩阵
    b = mid2 - mid1
    t = np.linalg.solve(A, b)
    center = mid1 + t[0] * dir1  # 圆心坐标

    # 计算半径
    radius = np.linalg.norm(center - p1)
    return center, radius, normal


def plot_triangle_and_circle_3d(ax, p1, p2, p3):
    """
    绘制给定三点构成的三角形，并画出外接圆
    :param p1, p2, p3: 三个点的坐标 (x, y, z)
    """
    # 计算圆心和半径
    center, radius, normal = calculate_circle_3d(p1, p2, p3)

    # 绘制圆
    # 生成圆的参数方程
    # 选择一个与normal垂直的向量作为基向量u
    u = np.array([1, 0, 0]) if abs(normal[0]) < 1 else np.array([0, 1, 0])

    # 计算两个基向量 v1 和 v2，确保它们垂直于法向量并且平行于圆的平面
    v1 = np.cross(normal, u)
    v1 = v1 / np.linalg.norm(v1)  # 单位化
    v2 = np.cross(normal, v1)  # 另一垂直向量

    # 生成圆上的点
    theta = np.linspace(0, 2 * np.pi, 100)
    circle_points = np.array([
        center + radius * (np.cos(t) * v1 + np.sin(t) * v2)
        for t in theta
    ])

    # 绘制圆
    ax.plot(circle_points[:, 0], circle_points[:, 1], circle_points[:, 2], color='grey', linestyle='--', linewidth=2)

    # 绘制圆心
    ax.scatter(center[0], center[1], center[2], color='red')

